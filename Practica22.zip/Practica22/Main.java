import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        Persona p1 = new Persona("Juan", LocalDate.of(1990, 1, 15), "Canal periferico");
        System.out.println("============Persona===========");
        System.out.println(p1);
        System.out.println("Edad: " + p1.obtenerEdad() + " años");
        p1.AdultoMayor();
        //Termina persona

        //Inicia trabajador
        Trabajador t1 = new Trabajador("Carlos", LocalDate.of(1985, 6, 10), "Monterrey", LocalDate.of(2010, 2, 1), 25000, "Profesor");
        System.out.println("============Trabajador============");
        System.out.println(t1);
        t1.CalculoAnti();
        t1.SolciVaca();
        //Termina trabajador

        //Inicia PAS
        Trabajador [] trabajador = new Trabajador [3];
        PAS pas1 = new PAS("María", LocalDate.of(1992, 4, 5), "Monterrey", LocalDate.of(2015, 3, 1), 18000, "Administrativo","Escolar", 3 , "Matutino", trabajador);
        System.out.println("============PAS============");
        pas1.administrarRecursos();
        pas1.generarReporte();
        //Termina PAS

        //Inicia Universidad
        Universidad universdad = new Universidad(" Apalo", "Monterrey", 1990);
        System.out.println("============Universidad============");
        System.out.println(universdad);
        //Termina Universidad
        //Inicia Departamento
       
        System.out.println("============Departamento============");
         Departamento sistemas = new Departamento("Computación", "Edificio A", "CS101", new PDI[10]);
         System.out.println(sistemas);
         PDI profesor1 = new PDI("Dr. García", "Titular", 20);
         PDI profesor2 = new PDI("Dra. López", "Asociado", 15);
         System.out.println("=====Profesores agregados al departamento===== ");
        sistemas.agregarProfesor(profesor1);
        sistemas.agregarProfesor(profesor2);
       System.out.println(profesor1);
       System.out.println(profesor2);
        //Termina Departamento
        //Inicia EstudianteGrado
        System.out.println("============EstudianteGrado============");
        EstudianteGrado est1 = new EstudianteGrado( "Leonardo", LocalDate.of(2007,5,20), "Saltillo", "A001",  9.5, LocalDate.of(2024,8,1), "Tesis",  320, true);
        System.out.println(est1);
        System.out.println("Beca obtenida: " + est1.calcularBeca());
        EstudianteGrado est2 = new EstudianteGrado( "Maria", LocalDate.of(2008,3,15), "Monterrey", "A002",  8.5, LocalDate.of(2024,8,1), "Tesis",  280, false);
        System.out.println(est2);
        System.out.println("Beca obtenida: " + est2.calcularBeca());
        //Termina EstudianteGrado

        //Inicia EstudianteDoctorado
        EstudianteDoctorado doc1 = new EstudianteDoctorado( "Ana", LocalDate.of(1998,3,10),"Monterrey",  "D001", 9.8,LocalDate.of(2025,1,10), "Curso a IA", "Afectaciones de IA", "Dr. García");
        System.out.println("============EstudianteDoctorado============");
        System.out.println(doc1);
        doc1.realizarTesis("Tema de tesis", "Dr. García");
        doc1.publicarArticulo("Tema de tesis", "Programa de investigación");
        //Termina EstudianteDoctorado
        
        //Inicia PDI
        PDI profesor = new PDI( "Profesor", "Titular", 20);
        System.out.println("============PDI============");
        System.out.println(profesor);
        //Termina PDI
    }
}