public class Universidad {
    private String nombre;
    private String ciudad;
    private int fundacion;
    private Departamento [] departamentos;
    private Estudiante [] estudiantes;
    private Trabajador [] trabajos;
    private int contEstudiantes;
    private int contTrabajos;
    private int contDepartamentos;
    public Universidad(String nombre, String ciudad, int fundacion){
    this .nombre = nombre;
    this.ciudad = ciudad;
    this.fundacion = fundacion;
    estudiantes = new Estudiante[100];
    trabajos = new Trabajador[100];
    departamentos = new Departamento[20];
    this.contEstudiantes = 0;
    this.contTrabajos = 0;
    this.contDepartamentos = 0;

    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getNombre(){
        return nombre;
    }
    public void setCiudad(String ciudad){
        this.ciudad = ciudad;
    }
    public String getCiudad(){
        return ciudad;
    }
    public void setFundacion(int fundacion){
        this.fundacion = fundacion;
    }
    public int getFundacion(){
        return fundacion;
    }
    public void agregarDepartamento(Departamento [] departamentos, Departamento departamento, int contDepartamentos ){
        for(int i = 0; i < departamentos.length; i++){
            if(contDepartamentos < departamentos.length){
            departamentos[contDepartamentos] = departamento;
            contDepartamentos++;
            break;
            } else {
                System.out.println("No se pueden agregar mas departamentos");
            }
        }
    }
    
    public void agregarEstudiante(Estudiante [] estudiante, int contEstudiantes){
       for(int i = 0; i < estudiante.length; i++){
        if(contEstudiantes < estudiante.length){
            estudiante[contEstudiantes] = estudiante[contEstudiantes];
            contEstudiantes++;
        } else {
            System.out.println("No se pueden agregar mas estudiantes");
            }
        }
        
    }
    public void agregarTrabajador(Trabajador  [] trabajador, int contTrabajos){
        for(int i = 0; i < trabajador.length; i++){
            if(contTrabajos < trabajador.length){
                trabajador[contTrabajos] = trabajador[contTrabajos];
                contTrabajos++;
            } else {
                System.out.println("No se pueden agregar mas trabajadores");
            }
        }
    }
    public void mostrarEstudiantes(){
        for(int i = 0; i < contEstudiantes; i++){
            System.out.println(estudiantes[i]);
            System.out.println("===================");
        }
    }

    public void mostrarTrabajadores(){
        for(int i = 0; i < contTrabajos; i++){
            System.out.println(trabajos[i]);
            System.out.println("===================");
        }
    }

    public void mostrarDepartamentos(){
        for(int i = 0; i < contDepartamentos; i++){
            System.out.println(departamentos[i]);
            System.out.println("===================");
        }
    }
    @Override
    public String toString(){
        return "Universidad " + getNombre() + " ubicada en " + getCiudad() + " fundada en el año " + getFundacion();
    } 
}
