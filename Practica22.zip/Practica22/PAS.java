import java.time.*;
public class PAS {
  private String area;
  private int nivel;
  private String turno;
  private Trabajador [] trabajador = new Trabajador [3];
 public PAS(String nombre , LocalDate fechaNacimiento , String direccion , LocalDate fechaIngreso ,double Salario, String puesto, String area, int nivel, String turno , Trabajador [] trabajador){
  this.trabajador[0] = new Trabajador("Laura", LocalDate.of(1985,4,15),  "Monterrey",  LocalDate.of(2012,1,1),  18000,   "Administrativo");
  this.trabajador[1] = new Trabajador("Pedro", LocalDate.of(1990,5,20), "Puebla", LocalDate.of(2015,3,1), 20000, "Administrativo");
  this.trabajador[2] = new Trabajador("María", LocalDate.of(1988,7,10), "Querétaro", LocalDate.of(2018,6,1), 22000, "Administrativo");
    this.area = area;
    this.turno = turno;
    this.nivel = nivel;
 }
 public void setArea(String area){
  this.area = area;
 }
 public String getArea(){
 return area;
 }
 public void setTurno(String turno){
   this.turno = turno;
 }
 public String getTurno(){
   return turno;
 }
 public void setNivel(int nivel){
   this.nivel = nivel;
 }
 public int getNivel(){
   return nivel;
 }

  public void administrarRecursos(){
   for(int i = 0 ; i <trabajador.length; i++){
      System.out.println("Trabajador: " 
      +trabajador[i].getNombre()+
      " Pertenece al area: "
      +getArea());
   }
  }
 public void generarReporte(){
  System.out.println("Reporte de Trabajadores del PAS:");
   for(int i = 0 ; i < trabajador.length; i++){
    System.out.println("Trabajador: " + (i+1) + " - " + trabajador[i].getNombre() +
    "\nArea: "+getArea()+
    "\nTurno: "+getTurno()+
    "\nNivel: "+getNivel()+
    "\n direccion: "+trabajador[i].getDireccion()+
    "\n fecha de ingreso: "+trabajador[i].getFechaIngreso()+
    "\n salario: "+trabajador[i].getSalario()+
    "\n puesto: "+trabajador[i].getPuesto());
  }
 }































}